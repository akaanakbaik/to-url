import express, { type Express, Request } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertWaitlistSchema, insertMediaFileSchema } from "@shared/schema";
import multer from "multer";
import path from "path";
import sharp from "sharp";
import { FFmpeg } from "@ffmpeg/ffmpeg";
import { fetchFile, toBlobURL } from "@ffmpeg/util";
import fs from "fs";

const upload = multer({
  storage: multer.memoryStorage(),
  limits: {
    fileSize: 50 * 1024 * 1024, // 50MB limit
  },
  fileFilter: (_req, file, cb) => {
    const fileType = file.mimetype.split('/')[0];
    if (!['image', 'video', 'audio'].includes(fileType)) {
      cb(new Error('Invalid file type'));
      return;
    }
    cb(null, true);
  },
});

interface FileRequest extends Request {
  file?: Express.Multer.File;
}

// Helper function to determine optimal format
function getOptimalFormat(mimeType: string): string {
  const fileType = mimeType.split('/')[0];
  console.log('Processing file type:', fileType, 'MIME:', mimeType);

  switch (fileType) {
    case 'image':
      if (mimeType.includes('png') || mimeType.includes('webp')) {
        return 'png';
      }
      return 'jpg';
    case 'video':
      return 'mp4';
    case 'audio':
      return 'mp3';
    default:
      throw new Error('Unsupported file type');
  }
}

// Helper function to validate URL
async function validateUrl(url: string): Promise<{ valid: boolean; mimeType?: string }> {
  try {
    const response = await fetch(url, { method: 'HEAD' });
    if (!response.ok) return { valid: false };

    const contentType = response.headers.get('content-type');
    if (!contentType) return { valid: false };

    const fileType = contentType.split('/')[0];
    if (!['image', 'video', 'audio'].includes(fileType)) {
      return { valid: false };
    }

    return { valid: true, mimeType: contentType };
  } catch {
    return { valid: false };
  }
}

// Helper function to process media
async function processMedia(buffer: Buffer, format: string, mimeType: string): Promise<Buffer> {
  console.log('Processing media:', { format, mimeType });
  const fileType = mimeType.split('/')[0];

  if (fileType === 'image') {
    console.log('Processing image with Sharp');
    const sharpImage = sharp(buffer);
    if (format === 'jpg') {
      return await sharpImage
        .jpeg({ quality: 85, progressive: true })
        .toBuffer();
    } else if (format === 'png') {
      return await sharpImage
        .png({ compressionLevel: 9 })
        .toBuffer();
    }
  } else if (fileType === 'video' || fileType === 'audio') {
    console.log('Processing video/audio with FFmpeg');
    const ffmpeg = new FFmpeg();
    await ffmpeg.load();

    const inputFileName = `input.${mimeType.split('/')[1]}`;
    const outputFileName = `output.${format}`;

    // Convert Buffer to Uint8Array for FFmpeg
    const uint8Array = new Uint8Array(buffer);
    await ffmpeg.writeFile(inputFileName, uint8Array);

    const ffmpegArgs = ['-i', inputFileName];
    if (fileType === 'video') {
      ffmpegArgs.push(
        '-c:v', 'libx264',
        '-preset', 'medium',
        '-crf', '23',
        '-c:a', 'aac',
        '-b:a', '128k'
      );
    } else {
      ffmpegArgs.push(
        '-b:a', '192k',
        '-c:a', 'libmp3lame'
      );
    }
    ffmpegArgs.push(outputFileName);

    console.log('FFmpeg command:', ffmpegArgs.join(' '));
    await ffmpeg.exec(ffmpegArgs);
    const data = await ffmpeg.readFile(outputFileName);

    // Cleanup
    await ffmpeg.deleteFile(inputFileName);
    await ffmpeg.deleteFile(outputFileName);

    return Buffer.from(data);
  }

  throw new Error('Unsupported format conversion');
}

const UPLOADS_DIR = path.join(process.cwd(), "uploads");
// Create uploads directory if it doesn't exist
if (!fs.existsSync(UPLOADS_DIR)) {
  fs.mkdirSync(UPLOADS_DIR, { recursive: true });
  console.log('Created uploads directory:', UPLOADS_DIR);
}

export async function registerRoutes(app: Express): Promise<Server> {
  // File upload and conversion endpoint
  app.post("/api/convert", upload.single("file"), async (req: FileRequest, res) => {
    console.log('Received file upload request');
    console.log('Request headers:', req.headers);
    console.log('Request body:', req.body);

    try {
      if (!req.file) {
        console.log('No file in request:', {
          body: req.body,
          files: req.files,
          headers: req.headers
        });
        return res.status(400).json({
          success: false,
          message: "No file uploaded",
          error: "MISSING_FILE"
        });
      }

      console.log('Processing file:', req.file.originalname, 'Type:', req.file.mimetype);
      const format = req.body.targetFormat || getOptimalFormat(req.file.mimetype);
      console.log('Selected format:', format);

      const convertedBuffer = await processMedia(
        req.file.buffer,
        format,
        req.file.mimetype
      );

      // Generate filename with timestamp to avoid collisions
      const filename = `${Date.now()}-${path.basename(
        req.file.originalname,
        path.extname(req.file.originalname)
      )}.${format}`;
      const convertedUrl = `/uploads/${filename}`;

      // Save the converted file
      const filePath = path.join(UPLOADS_DIR, filename);
      fs.writeFileSync(filePath, convertedBuffer);
      console.log('Saved converted file to:', filePath);

      // Save to storage
      const mediaFile = await storage.saveMediaFile({
        originalName: req.file.originalname,
        convertedUrl,
        fileType: req.file.mimetype.split("/")[0] as "image" | "video" | "audio",
        format: format as "jpg" | "png" | "mp4" | "mp3",
      });

      console.log('Conversion successful:', mediaFile);
      res.json({
        success: true,
        ...mediaFile,
        message: "File converted successfully",
        format,
        size: convertedBuffer.length
      });
    } catch (error) {
      console.error('Conversion error:', error);
      res.status(500).json({
        success: false,
        message: error instanceof Error ? error.message : "Internal server error",
        error: "CONVERSION_FAILED"
      });
    }
  });

  // Serve static files from uploads directory
  app.use('/uploads', express.static(UPLOADS_DIR));

  // Get recent conversions
  app.get("/api/recent", async (_req, res) => {
    try {
      const recentFiles = await storage.getRecentFiles(10);
      res.json(recentFiles);
    } catch (error) {
      res.status(500).json({
        success: false,
        message: "Failed to fetch recent conversions",
        error: "FETCH_FAILED"
      });
    }
  });

  // Status check endpoint
  app.get("/api/status", (_req, res) => {
    res.json({
      status: "ok",
      version: "1.0",
      supportedFormats: {
        image: ["jpg", "png"],
        video: ["mp4"],
        audio: ["mp3"]
      }
    });
  });

  // API endpoint for WhatsApp bot
  app.post("/api/convert-url", async (req, res) => {
    try {
      const { url } = req.body;
      if (!url) {
        return res.status(400).json({
          success: false,
          message: "URL is required",
          error: "MISSING_URL"
        });
      }

      // Validate URL
      const validation = await validateUrl(url);
      if (!validation.valid || !validation.mimeType) {
        return res.status(400).json({
          success: false,
          message: "Invalid or unsupported media URL",
          error: "INVALID_URL"
        });
      }

      // Download and process the file
      const response = await fetch(url);
      const buffer = await response.arrayBuffer();
      const format = getOptimalFormat(validation.mimeType);

      // Process the media
      const convertedBuffer = await processMedia(
        Buffer.from(buffer),
        format,
        validation.mimeType
      );

      // Generate filename and save
      const filename = `${Date.now()}-${path.basename(url)}`;
      const convertedUrl = `/uploads/${filename}.${format}`;

      fs.writeFileSync(path.join(UPLOADS_DIR, `${filename}.${format}`), convertedBuffer);


      // Save to storage
      const mediaFile = await storage.saveMediaFile({
        originalName: path.basename(url),
        convertedUrl,
        fileType: validation.mimeType.split('/')[0] as "image" | "video" | "audio",
        format: format as "jpg" | "png" | "mp4" | "mp3",
      });

      res.json({
        success: true,
        ...mediaFile,
        size: convertedBuffer.length,
        message: "File converted successfully"
      });
    } catch (error) {
      console.error('URL conversion error:', error);
      res.status(500).json({
        success: false,
        message: error instanceof Error ? error.message : "Failed to convert from URL",
        error: "CONVERSION_FAILED"
      });
    }
  });

  app.post("/api/waitlist", async (req, res) => {
    try {
      const data = insertWaitlistSchema.parse(req.body);
      const entry = await storage.addToWaitlist(data);
      res.json(entry);
    } catch (error) {
      if (error instanceof Error) {
        res.status(400).json({ message: error.message });
      } else {
        res.status(500).json({ message: "Internal server error" });
      }
    }
  });

  app.get("/api/waitlist/count", async (_req, res) => {
    try {
      const count = await storage.getWaitlistCount();
      res.json({ count });
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  return createServer(app);
}