import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { motion, AnimatePresence } from "framer-motion";
import { useMutation, useQuery } from "@tanstack/react-query";
import { insertWaitlistSchema, type InsertWaitlist } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormMessage,
} from "@/components/ui/form";
import { useToast } from "@/hooks/use-toast";
import { queryClient } from "@/lib/queryClient";
import { Building2, Users, Zap, Upload, Copy, FileType, Image, Video, Music } from "lucide-react";
import { SiGithub } from "react-icons/si";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

export default function Home() {
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [targetFormat, setTargetFormat] = useState<string>("");
  const [urlInput, setUrlInput] = useState<string>("");
  const { toast } = useToast();

  const recentFiles = useQuery({
    queryKey: ["/api/recent"],
  });

  const convertMutation = useMutation({
    mutationFn: async (formData: FormData) => {
      console.log('FormData contents:');
      for (const pair of formData.entries()) {
        console.log(pair[0], pair[1]);
      }

      const response = await fetch('/api/convert', {
        method: 'POST',
        body: formData,
        credentials: 'include'
      });

      console.log('Response status:', response.status);
      const responseText = await response.text();
      console.log('Response text:', responseText);

      if (!response.ok) {
        let errorMessage;
        try {
          const errorData = JSON.parse(responseText);
          errorMessage = errorData.message || 'Failed to convert file';
        } catch {
          errorMessage = responseText || 'Failed to convert file';
        }
        throw new Error(errorMessage);
      }

      return JSON.parse(responseText);
    },
    onSuccess: (data) => {
      toast({
        title: "Success!",
        description: `File converted to ${data.format} successfully`,
      });
      setSelectedFile(null);
      recentFiles.refetch();
    },
    onError: (error: Error) => {
      console.error('Conversion error:', error);
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const convertUrlMutation = useMutation({
    mutationFn: async (url: string) => {
      const response = await fetch('/api/convert-url', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ url }),
        credentials: 'include'
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || 'Failed to convert URL');
      }

      return response.json();
    },
    onSuccess: (data) => {
      toast({
        title: "Success!",
        description: `URL converted to ${data.format} successfully`,
      });
      setUrlInput("");
      recentFiles.refetch();
    },
    onError: (error: Error) => {
      console.error('URL conversion error:', error);
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      console.log('File selected:', file.name, 'Type:', file.type, 'Size:', file.size);
      setSelectedFile(file);
      // Auto-detect format based on file type
      const fileType = file.type.split("/")[0];
      if (fileType === "image") {
        setTargetFormat(file.type.includes("png") ? "png" : "jpg");
      } else if (fileType === "video") {
        setTargetFormat("mp4");
      } else if (fileType === "audio") {
        setTargetFormat("mp3");
      }
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedFile) {
      console.log('No file selected');
      return;
    }

    console.log('Creating FormData with file:', selectedFile.name);
    const formData = new FormData();
    formData.append("file", selectedFile);
    if (targetFormat) {
      formData.append("targetFormat", targetFormat);
    }

    try {
      await convertMutation.mutateAsync(formData);
    } catch (error) {
      console.error('Error uploading:', error);
      toast({
        title: "Error",
        description: "Failed to upload file",
        variant: "destructive",
      });
    }
  };

  const handleUrlSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!urlInput) return;

    try {
      await convertUrlMutation.mutateAsync(urlInput);
    } catch (error) {
      console.error('URL conversion error:', error);
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to convert URL",
        variant: "destructive",
      });
    }
  };

  const copyToClipboard = (url: string) => {
    navigator.clipboard.writeText(url).then(() => {
      toast({
        title: "Copied!",
        description: "URL copied to clipboard",
      });
    });
  };

  const formatFileSize = (bytes: number) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  const containerVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: {
        duration: 0.6,
        staggerChildren: 0.1
      }
    }
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: { opacity: 1, y: 0 }
  };

  return (
    <motion.div 
      className="min-h-screen bg-gradient-to-b from-primary/5 to-white"
      initial="hidden"
      animate="visible"
      variants={containerVariants}
    >
      <main className="container mx-auto px-4 py-8">
        <motion.div 
          className="text-center mb-12"
          variants={itemVariants}
        >
          <h1 className="text-4xl md:text-5xl font-bold bg-gradient-to-r from-primary to-primary/70 bg-clip-text text-transparent mb-4">
            Media Converter
          </h1>
          <p className="text-muted-foreground text-lg md:text-xl">
            Convert your media files or URLs to various formats instantly
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-4xl mx-auto mb-12">
          {/* File Upload Card */}
          <motion.div variants={itemVariants}>
            <Card className="shadow-lg hover:shadow-xl transition-shadow duration-300">
              <CardContent className="p-6">
                <h3 className="text-lg font-semibold mb-4">Upload File</h3>
                <form onSubmit={handleSubmit} className="space-y-6">
                  <motion.div 
                    className="border-2 border-dashed border-primary/20 hover:border-primary/40 transition-colors rounded-lg p-8 text-center"
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                  >
                    <input
                      type="file"
                      onChange={handleFileChange}
                      className="hidden"
                      id="file-upload"
                      accept="image/*,video/*,audio/*"
                    />
                    <label
                      htmlFor="file-upload"
                      className="cursor-pointer flex flex-col items-center"
                    >
                      <motion.div
                        whileHover={{ rotate: 15 }}
                        transition={{ type: "spring", stiffness: 300 }}
                      >
                        <Upload className="h-12 w-12 text-primary mb-4" />
                      </motion.div>
                      <span className="text-muted-foreground">
                        {selectedFile ? selectedFile.name : "Click to upload a file"}
                      </span>
                    </label>
                  </motion.div>

                  <AnimatePresence>
                    {selectedFile && (
                      <motion.div
                        initial={{ opacity: 0, height: 0 }}
                        animate={{ opacity: 1, height: "auto" }}
                        exit={{ opacity: 0, height: 0 }}
                      >
                        <Select value={targetFormat} onValueChange={setTargetFormat}>
                          <SelectTrigger>
                            <SelectValue placeholder="Auto-detect format" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="jpg">JPG</SelectItem>
                            <SelectItem value="png">PNG</SelectItem>
                            <SelectItem value="mp4">MP4</SelectItem>
                            <SelectItem value="mp3">MP3</SelectItem>
                          </SelectContent>
                        </Select>
                      </motion.div>
                    )}
                  </AnimatePresence>

                  <Button
                    type="submit"
                    className="w-full relative overflow-hidden"
                    disabled={!selectedFile || convertMutation.isPending}
                  >
                    {convertMutation.isPending ? (
                      <motion.div
                        className="absolute inset-0 bg-primary/20"
                        animate={{
                          x: ["0%", "100%"],
                        }}
                        transition={{
                          duration: 1,
                          repeat: Infinity,
                          ease: "linear",
                        }}
                      />
                    ) : null}
                    <span className="relative z-10">
                      {convertMutation.isPending ? "Converting..." : "Convert"}
                    </span>
                  </Button>
                </form>
              </CardContent>
            </Card>
          </motion.div>

          {/* URL Input Card */}
          <motion.div variants={itemVariants}>
            <Card className="shadow-lg hover:shadow-xl transition-shadow duration-300">
              <CardContent className="p-6">
                <h3 className="text-lg font-semibold mb-4">Convert from URL</h3>
                <form onSubmit={handleUrlSubmit} className="space-y-6">
                  <div className="space-y-4">
                    <Input
                      type="url"
                      placeholder="Enter media URL"
                      value={urlInput}
                      onChange={(e) => setUrlInput(e.target.value)}
                      className="focus:ring-primary"
                    />
                    <Button
                      type="submit"
                      className="w-full relative overflow-hidden"
                      disabled={!urlInput || convertUrlMutation.isPending}
                    >
                      {convertUrlMutation.isPending ? (
                        <motion.div
                          className="absolute inset-0 bg-primary/20"
                          animate={{
                            x: ["0%", "100%"],
                          }}
                          transition={{
                            duration: 1,
                            repeat: Infinity,
                            ease: "linear",
                          }}
                        />
                      ) : null}
                      <span className="relative z-10">
                        {convertUrlMutation.isPending ? "Converting..." : "Convert URL"}
                      </span>
                    </Button>
                  </div>
                </form>
              </CardContent>
            </Card>
          </motion.div>
        </div>

        {/* Recent Conversions */}
        <motion.div 
          className="max-w-4xl mx-auto"
          variants={itemVariants}
        >
          <h2 className="text-2xl font-semibold mb-6 text-foreground">
            Recent Conversions
          </h2>
          <div className="grid gap-4">
            <AnimatePresence>
              {recentFiles.data?.map((file: any) => (
                <motion.div
                  key={file.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -20 }}
                  layout
                >
                  <Card className="shadow-md hover:shadow-lg transition-all duration-300 transform hover:-translate-y-1">
                    <CardContent className="p-4 flex items-center justify-between">
                      <div className="flex items-center gap-4">
                        <motion.div whileHover={{ scale: 1.1 }} whileTap={{ scale: 0.9 }}>
                          {file.fileType === "image" && (
                            <Image className="h-6 w-6 text-primary" />
                          )}
                          {file.fileType === "video" && (
                            <Video className="h-6 w-6 text-primary" />
                          )}
                          {file.fileType === "audio" && (
                            <Music className="h-6 w-6 text-primary" />
                          )}
                        </motion.div>
                        <div>
                          <p className="font-medium text-foreground">{file.originalName}</p>
                          <p className="text-sm text-muted-foreground">
                            Converted to {file.format.toUpperCase()}
                            {file.size && ` • ${formatFileSize(file.size)}`}
                          </p>
                        </div>
                      </div>
                      <motion.div whileHover={{ scale: 1.05 }}>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => copyToClipboard(file.convertedUrl)}
                          className="hover:bg-primary/5"
                        >
                          <Copy className="h-4 w-4 mr-2" />
                          Copy URL
                        </Button>
                      </motion.div>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </AnimatePresence>
          </div>
        </motion.div>

        {/* Developer Card */}
        <motion.div
          variants={itemVariants}
          className="mt-20"
        >
          <Card className="max-w-md mx-auto bg-primary/5 shadow-xl hover:shadow-2xl transition-shadow duration-300">
            <CardContent className="p-6 text-center">
              <motion.div
                initial={{ scale: 0.5, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                transition={{ type: "spring", stiffness: 300 }}
              >
                <h3 className="text-xl font-semibold text-primary mb-2">Developer</h3>
                <p className="text-muted-foreground mb-4">
                  Created with ❤️ by Media Converter Team
                </p>
                <div className="flex justify-center gap-4">
                  <motion.a
                    href="https://github.com/yourusername"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-2 text-primary hover:text-primary/80 transition-colors"
                    whileHover={{ scale: 1.1 }}
                    whileTap={{ scale: 0.9 }}
                  >
                    <SiGithub className="h-5 w-5" />
                    <span>GitHub</span>
                  </motion.a>
                </div>
              </motion.div>
            </CardContent>
          </Card>
        </motion.div>
      </main>
    </motion.div>
  );
}