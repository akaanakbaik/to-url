import { waitlist, type Waitlist, type InsertWaitlist } from "@shared/schema";
import { mediaFiles, type MediaFile, type InsertMediaFile } from "@shared/schema";
import fs from "fs";
import path from "path";

export interface IStorage {
  addToWaitlist(entry: InsertWaitlist): Promise<Waitlist>;
  getWaitlistCount(): Promise<number>;
  saveMediaFile(file: InsertMediaFile): Promise<MediaFile>;
  getMediaFile(id: number): Promise<MediaFile | undefined>;
  getRecentFiles(limit: number): Promise<MediaFile[]>;
}

interface JsonDatabase {
  waitlist: Waitlist[];
  mediaFiles: MediaFile[];
  currentId: number;
}

export class JsonStorage implements IStorage {
  private db: JsonDatabase;
  private dbPath: string;

  constructor() {
    this.dbPath = path.join(process.cwd(), "database.json");
    this.db = this.loadDatabase();
  }

  private loadDatabase(): JsonDatabase {
    try {
      if (fs.existsSync(this.dbPath)) {
        const data = fs.readFileSync(this.dbPath, "utf-8");
        return JSON.parse(data);
      }
    } catch (error) {
      console.error("Error loading database:", error);
    }

    // Return empty database if file doesn't exist or is corrupted
    return {
      waitlist: [],
      mediaFiles: [],
      currentId: 1,
    };
  }

  private saveDatabase(): void {
    try {
      fs.writeFileSync(this.dbPath, JSON.stringify(this.db, null, 2));
    } catch (error) {
      console.error("Error saving database:", error);
    }
  }

  async addToWaitlist(entry: InsertWaitlist): Promise<Waitlist> {
    const existingEntry = this.db.waitlist.find((w) => w.email === entry.email);
    if (existingEntry) {
      throw new Error("Email already registered");
    }

    const id = this.db.currentId++;
    const waitlistEntry: Waitlist = {
      id,
      email: entry.email,
      joinedAt: new Date(),
    };

    this.db.waitlist.push(waitlistEntry);
    this.saveDatabase();
    return waitlistEntry;
  }

  async getWaitlistCount(): Promise<number> {
    return this.db.waitlist.length;
  }

  async saveMediaFile(file: InsertMediaFile): Promise<MediaFile> {
    const id = this.db.currentId++;
    const mediaFile: MediaFile = {
      id,
      ...file,
      uploadedAt: new Date(),
    };

    this.db.mediaFiles.push(mediaFile);
    this.saveDatabase();
    return mediaFile;
  }

  async getMediaFile(id: number): Promise<MediaFile | undefined> {
    return this.db.mediaFiles.find((file) => file.id === id);
  }

  async getRecentFiles(limit: number): Promise<MediaFile[]> {
    return [...this.db.mediaFiles]
      .sort((a, b) => new Date(b.uploadedAt).getTime() - new Date(a.uploadedAt).getTime())
      .slice(0, limit);
  }
}

// Export a single instance to be used throughout the application
export const storage = new JsonStorage();