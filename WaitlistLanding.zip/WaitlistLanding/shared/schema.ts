import { pgTable, text, serial, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const waitlist = pgTable("waitlist", {
  id: serial("id").primaryKey(),
  email: text("email").notNull().unique(),
  joinedAt: timestamp("joined_at").defaultNow().notNull(),
});

export const insertWaitlistSchema = createInsertSchema(waitlist)
  .pick({ email: true })
  .extend({
    email: z.string().email("Please enter a valid email address"),
  });

export type InsertWaitlist = z.infer<typeof insertWaitlistSchema>;
export type Waitlist = typeof waitlist.$inferSelect;

export const mediaFiles = pgTable("media_files", {
  id: serial("id").primaryKey(),
  originalName: text("original_name").notNull(),
  convertedUrl: text("converted_url").notNull(),
  fileType: text("file_type").notNull(), // image/video/audio
  format: text("format").notNull(), // jpg/png/mp4/mp3
  uploadedAt: timestamp("uploaded_at").defaultNow().notNull(),
});

export const insertMediaFileSchema = createInsertSchema(mediaFiles)
  .pick({
    originalName: true,
    convertedUrl: true,
    fileType: true,
    format: true,
  })
  .extend({
    fileType: z.enum(["image", "video", "audio"]),
    format: z.enum(["jpg", "png", "mp4", "mp3"]),
  });

export type InsertMediaFile = z.infer<typeof insertMediaFileSchema>;
export type MediaFile = typeof mediaFiles.$inferSelect;